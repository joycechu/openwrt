#ifndef VERSION
#define VERSION "3proxy-0.9-devel"
#endif
#ifndef BUILDDATE
#define BUILDDATE ""
#endif
